package com.seegeek.cms.action;

public class Constance {
	//user  info
	public static final String GET_ALL="getAll";
	public static final String ADD_OBJECT="addObject";
	//role
	public static final String ROLE_GET_ALL="";
	
}
