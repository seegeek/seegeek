package com.seegeek.cms.service;

import com.seegeek.cms.domain.Role;


/**
 * @author  作者 zhaogaofei
 * @version  创建时间：May 12, 2015 12:17:53 PM
 * @email   zhaogaofei2012@163.com 
 * 类说明
 */
public interface IRoleService extends IBaseService<Role>{

}
